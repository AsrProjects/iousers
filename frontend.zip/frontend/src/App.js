import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import FormComponent from './compoments/FormCompoment';
import DataFetcher from './compoments/UserComponent';
import DeleteComponent from './compoments/DeleteComponent';
import UpdateComponent from './compoments/UpdateComponent';
import EditName from './compoments/EditName';
// import React from 'react';

// const handleUser = (e) => {

//   e.preventDefault();
//   console.log('form submitted');

// }

function App() {

  // const a = 1;
  // let compToRender;

  // if(a===1) {
  //   compToRender = <DataFetcher/>;
  // }
  // else{ compToRender = <FormComponent/>}

  return (
    <div className="App">

      {/* {compToRender} */}

      {/* {a === 1 ? <FormComponent/> : <DataFetcher/>}       */}


      <DataFetcher></DataFetcher>
      <hr />

      {/* <DeleteComponent></DeleteComponent>
      <hr/> */}

      {/* <UpdateComponent></UpdateComponent>
      <hr/> */}

      {/* <FormComponent></FormComponent> */}
{/* <EditName></EditName> */}
    </div>
  );
}

export default App;
