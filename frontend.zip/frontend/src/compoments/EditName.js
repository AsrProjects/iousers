import React, {useState} from "react";
import axios from "axios";

function EditName({userId}) {

    const [name, setName] = useState('');
    const [id, setId] = useState(0);
    setId(userId);
    console.log(id);

    const handleName = (event) => {setName(event.target.value);};
    // const handleMobile = (event) => {setMobile(event.target.value);};


    const edName = async(e) => {
        e.preventDefault();
        const eName = ({id, name});
        const response = await axios.put("http://localhost:5000/updatename", eName);   
    }

    return <div>
        <h1>Enter new name</h1>
        <form onSubmit={edName}>
            <div>
                <label>Name </label>
                <input 
                type="text" 
                value={name}
                onChange={handleName}
                required>
                </input>
            </div>
            <button type="submit">Update</button>
        </form>
    </div>
}

export default EditName;