import React, {useState} from "react";
import axios from "axios";

function EditAddress() {

    const [address, setAddress] = useState('');
    const [id, setId] = useState(0);

    console.log(id);

    const handleAddress = (event) => {setAddress(event.target.value);};
    // const handleMobile = (event) => {setMobile(event.target.value);};


    const editAddress = async(e) => {
        e.preventDefault();
        const eAddress = ({id, address});
        const response = await axios.put("http://localhost:5000/updateaddress", eAddress);   
    }

    return <div>
        <h1>Enter new address</h1>
        <form onSubmit={editAddress}>
            <div>
                <label>Address </label>
                <input 
                type="text" 
                value={address}
                onChange={handleAddress}
                required>
                </input>
            </div>
            <button type="submit">Update Address</button>
        </form>
    </div>
}

export default EditAddress;