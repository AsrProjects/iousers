import React, { useState, useEffect } from 'react';
import axios from 'axios';
import FormComponent from './FormCompoment';
import EditName from './EditName';

const DataFetcher = () => {

  // for checking count of users
  const [length, setLength] = useState(0);
  
  //to open edit name box
  const [NameId, setNameId] = useState(0);
  const [isEditNameVis, setIEditNameVis] = useState(false);
  const editNameClick = () => {
    setIEditNameVis(!isEditNameVis);
  }
  
  //To open add user box
  const [isComponentVisible, setIsComponentVisible] = useState(false);
  const addUserClick = () => {
    setIsComponentVisible(!isComponentVisible);
  };

  // const a = -1;
  // useEffect(() => {
  //   axios.get('http://localhost:5000/countUser')
  //   .then(response => {
  //     a = response;
  //     console.log(a);
  //   });
  // }, []);

  const [data, setData] = useState([]);

  //get call for all users details
  useEffect(() => {
    axios.get('http://localhost:5000/alluser')
      .then(response => {
        console.log(response.data);
        setData(response.data);
        setLength(response.data.length);
        console.log(length);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  //delete all users
  const deleteall = async (e) => {
    e.preventDefault();
    const response = await axios.delete("http://localhost:5000/deleteall");
  }

  //delete user by id 
  const deleteUser = async (userId) => {
    console.log(userId);

    const response = await axios.delete(`http://localhost:5000/deleteid/${userId}`);

  }


  if (length == 0) {
    return <div>
      <h1>Welcome to IO.</h1>
      <FormComponent></FormComponent>
    </div>
  } else {
      return (
    <div>
      <h1>Welcome to IO.</h1>
      <h2>Users Table</h2>

      {/* <ul>
        {data.map(user => (
          <li>{user.name} - {user.mobile}</li>
        ))}
      </ul> */}

      <table style={tableStyle}>
        <thead>

          <tr>
            <th style={headerCellStyle}>Name</th>
            <th style={headerCellStyle}>Mobile</th>
            <th style={headerCellStyle}>Email</th>
            <th style={headerCellStyle}>Address</th>
            {/* <th style={headerCellStyle}>City</th>
            <th style={headerCellStyle}>State</th>
            <th style={headerCellStyle}>Country</th> */}
            <th style={headerCellStyle}>Edit</th>
            <th style={headerCellStyle}>Delete</th>
          </tr>
        </thead>

        <tbody>
          {data.map((user) => (
            <tr key={user.id}>
{/* {NameId}=user.id; */}
              <td style={cellStyle}>{user.name}</td>
              <td style={cellStyle}>{user.mobile}</td>
              <td style={cellStyle}>{user.email}</td>
              <td style={cellStyle}>{user.address}</td>
              {/* <td style={cellStyle}>{user.city}</td>
              <td style={cellStyle}>{user.state}</td>
              <td style={cellStyle}>{user.country}</td> */}

              <td style={cellStyle}>  <select id="options" name="options">
                <option onClick={editNameClick(user.id)} value="name">Name</option>
                <option value="email">Email</option>
                <option value="phone">Mobile</option>
                <option value="address">Address</option>
              </select>
              </td>

              <td style={cellStyle}><button onClick={() => deleteUser(user.id)}>Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>


      {/* add a user button & deleteall button  */}
      <div style={buttonstyle}>
        <button onClick={addUserClick} style={bstyle}>
          {isComponentVisible ? 'Close the box' : 'Add a user'} </button>
        <button onClick={deleteall} style={bstyle}>Delete all users</button>
      </div>

      {/* user input form component */}
      <div>
        {isComponentVisible && <FormComponent />}
      </div>        



   
    </div>
  );
  }


};

const buttonstyle = {
  margin: '25px'
}
const bstyle = {
  margin: '20px'
}

const tableStyle = {
  width: '100%',
  // margin: '10px',
  borderCollapse: 'collapse',
  marginTop: '20px',
};

const headerCellStyle = {
  padding: '12px',
  backgroundColor: '#007BFF',
  color: 'white',
  border: '1px solid #ddd',
  textAlign: 'center',
};

const cellStyle = {
  padding: '10px',
  border: '1px solid #ddd',
};




export default DataFetcher;