import axios from "axios";
import React, { useState, useEffect } from "react";
import {CitySelect, CountrySelect, StateSelect} from 'react-country-state-city';
// import "react-country-state-city/dist/react-country-state-city.css";
import {Country, State, City} from 'country-state-city'

function FormComponent() {

    const [name, setName] = useState('');
    const [mobile, setMobile] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    // const [city, setCity] = useState('');
    // const [state, setState] = useState('');
    // const [country, setCountry] = useState('');
    const [countries, setCountries] = useState(Country.getAllCountries());
    const [states, setStates] = useState();
    const [cities, setCities] = useState();
    const [error, setError] = useState('');

    const [selectedCountry, setSelectedCountry] = useState(null);
    const [selectedState, setSelectedState] = useState(null);

    const handleName = (event) => {setName(event.target.value);};
    const handleMobile = (event) => {setMobile(event.target.value);};
    const handleEmail = (event) => {setEmail(event.target.value);};
    const handleAddress = (event) => {setAddress(event.target.value);};
    // const handleCity = (event) => {setCity(event.target.value);};
    // const handleState = (event) => {setState(event.target.value);};
    // const handleCountry = (event) => {setCountry(event.target.value);};

console.log(countries)
     
    const handleUser = async (e) =>{
     console.log("entry point");   
        e.preventDefault();
        const adduser = ({name, mobile, email, address, cities, states, countries});
        if (!email.includes('@')) {
            setError('Enter valid email id');
          } else if (mobile.length !== 10 || !/^\d+$/.test(mobile)) {
            setError('Phone number must be 10 digits');
          } else {
            setError('');
            const response = await axios.post("http://localhost:5000/adduser", adduser);
            // console.log('Form submitted:', { name, email, mobile, address, city, state, country });
            }
    }

    const handleCountryChange = (country) => {
        setSelectedCountry(country);
        setStates(State.getStatesOfCountry(country.isoCode));
        setCities([]);
    };

    const handleStateChange = (state) => {
        setSelectedState(state);
        setCities(City.getCitiesOfState(selectedCountry.isoCode, state.isoCode));
    };

return <div>
    <div>
    <h2>User Form</h2>
    <form  onSubmit={handleUser}>
    <div>
        <label>Name    </label>
        <input 
        type="text" 
        value={name}
        onChange={handleName}
        required
        ></input>
    </div>

    <div>
        <label>Mobile </label>
        <input
        type="number"
        value={mobile}
        onChange={handleMobile}
        pattern="\d{10}"
        required
        ></input>
    </div>

    <div>
        <label>Email  </label>
        <input
        type="text"
        value={email}
        onChange={handleEmail}
        required
        ></input>
    </div>

    <div>
        <label>Address</label>
        <input
        type="text"
        value={address}
        onChange={handleAddress}
        required
        ></input>
    </div>

    <div>
        <select className="form-select" 
            onChange={(e) => handleCountryChange(countries.find((c) => c.isoCode === e.target.value),)}>
            <option value=''>Select Country</option>
            {countries.map((country) => (
                <option key={country.isoCode} value=''>{country.name}</option>
            ))}
        </select>

        {/* <select disabled={!selectedCountry} className="form-select">
            <option value=''>Select State</option>
            {states.map((state) => (
                <option key={state.isoCode} value={state.isoCode}>{state.name}</option>
            ))}
        </select>

        <select disabled={!selectedState} className="form-select">
            <option value=''>Select City</option>
            {cities.map((city) => (
                <option key={city.name} value={city.name}>
                    {city.name}
                </option>
            ))}
        </select> */}
    </div>




    {/* <div>
        <label>Country</label>
        <CountrySelect
        onChange={(e) => {
          setCountry(e.id);
        }}
        value={country}
        placeHolder="Select Country"
      />
    </div>
    <div>
        <label>State</label>
        <StateSelect

        onChange={(e) => {
          setState(e.id);
        }}
        value={state}
        placeHolder="Select State"
      />
    </div>
    <div>
        <label>City</label>
        <CitySelect
        // value={handleCity}
        onChange={(e) => {
          setCity(e.id);
        }}
        value={city}
        placeHolder="Select City"
      />
    </div> */}


    {error && <p style={{ color: 'red' }}>{error}</p>}
    <button type="submit">Add user</button>
 </form>   
 </div>


</div>

};

export default FormComponent;