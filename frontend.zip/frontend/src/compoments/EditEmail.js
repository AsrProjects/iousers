import React, {useState} from "react";
import axios from "axios";

function EditEmail() {

    const [email, setEmail] = useState('');
    const [id, setId] = useState(0);

    console.log(id);

    const handleEmail = (event) => {setEmail(event.target.value);};
    // const handleMobile = (event) => {setMobile(event.target.value);};


    const editEmail = async(e) => {
        e.preventDefault();
        const eEmail = ({id, email});
        const response = await axios.put("http://localhost:5000/updateemail", eEmail);   
    }

    return <div>
        <h1>Enter new email</h1>
        <form onSubmit={editEmail}>
            <div>
                <label>Email </label>
                <input 
                type="text" 
                value={email}
                onChange={handleEmail}
                required>
                </input>
            </div>
            <button type="submit">Update Email</button>
        </form>
    </div>
}

export default EditEmail;