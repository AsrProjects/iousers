import axios from "axios";
import React, { useState } from "react";

function UpdateComponent() {

    const [name, setName] = useState('');
    const [mobile, setMobile] = useState(0);

    const handleName = (event) => {setName(event.target.value);};
    const handleMobile = (event) => {setMobile(event.target.value);};

    const handleUser = async (e) => {
        e.preventDefault();
        const updateUser = ({mobile, name});
        const response = await axios.put("http://localhost:5000/updateuser", updateUser);

    }


    return <div>
        <h1>Update user mobile no. using Name</h1>
        <form onSubmit={handleUser}>
            <div>
            <label>Name  </label>
            <input
            type="text"
            value={name}
            onChange={handleName}
            required
            ></input>
            </div>
            <div>
            <label>Mobile</label>
            <input
            type="number"
            value={mobile}
            onChange={handleMobile}
            required
            ></input>
            </div>
            <button type="submit">Update</button>          
        </form>
    </div>
};

export default UpdateComponent;