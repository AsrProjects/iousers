import React, {useState} from "react";
import axios from "axios";

function EditMobile() {

    const [mobile, setMobile] = useState('');
    const [id, setId] = useState(0);

    console.log(id);

    const handleMobile = (event) => {setMobile(event.target.value);};
    // const handleMobile = (event) => {setMobile(event.target.value);};


    const editMobile = async(e) => {
        e.preventDefault();
        const eMobile = ({id, mobile});
        const response = await axios.put("http://localhost:5000/updatemobile", eMobile);   
    }

    return <div>
        <h1>Enter new Mobile</h1>
        <form onSubmit={editMobile}>
            <div>
                <label>Mobile </label>
                <input 
                type="text" 
                value={mobile}
                onChange={handleMobile}
                required>
                </input>
            </div>
            <button type="submit">Update Mobile</button>
        </form>
    </div>
}

export default EditMobile;