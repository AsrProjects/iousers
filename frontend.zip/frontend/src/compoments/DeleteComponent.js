import React, { useState } from "react";
import axios from "axios";

function DeleteComponent() {

    const [name, setName] = useState('');

    const handleName = (event) => {setName(event.target.value);};

    const handleUser = async (e) => {
        e.preventDefault();
        const response = await axios.delete("http://localhost:5000/deleteUser", {data: {name}
        });
    }


    return <div>
        <h2>Delete a user</h2>
        <form onSubmit={handleUser}>
            <div>
                <label>Enter name   </label>
                <input
                type="text"
                value={name}
                onChange={handleName}
                required
                ></input>
            </div>

            <button type="submit"> Delete user</button>

        </form>
    </div>
};

export default DeleteComponent;